/*
 *  hw_def.h
 *
 *  Created on: Feb 08, 2018
 *      Author: opus
 */





#ifndef HW_DEF_H
#define HW_DEF_H



#define _HW_DEF_ADC_X_AXIS                1
#define _HW_DEF_ADC_Y_AXIS                0

#define _HW_DEF_BUTTON_A                  1
#define _HW_DEF_BUTTON_B                  2
#define _HW_DEF_BUTTON_MENU               3
#define _HW_DEF_BUTTON_HOME               4
#define _HW_DEF_BUTTON_C                  5
#define _HW_DEF_BUTTON_D                  6


#endif

